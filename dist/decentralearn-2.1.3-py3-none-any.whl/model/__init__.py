#init func
